package testing;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class JotFormAutomation {
    public static void main(String[] args) {
        
 
    	WebDriverManager.chromedriver().setup();
    	WebDriver driver = new ChromeDriver();

        driver.manage().window().maximize();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        Actions actions = new Actions(driver);

        try {
			// Step 1: Open JotForm
            driver.get("https://www.jotform.com/myworkspace/");
            

            // Step 2: Click on "Create"
            WebElement createFormBtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@aria-label=' CREATE']")));
            createFormBtn.click();
            
            // Step 3: click "form"
            WebElement form = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@aria-label='Form']//div[@class='productIconWrapper']")));
            form.click();
            
            // Step 4: Select "Start from Scratch"
            WebElement scratchOption = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='jfWizard-list-item-icon-wrapper']")));
            scratchOption.click();
            
            // Step 5: Choose "Classic Form"
            WebElement classicForm = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@aria-label='Classic form']//div[@class='jfWizard-list-item-icon-wrapper withMobileIcon']")));
            classicForm.click();
            
            // Step 6: click on "Add element"
            WebElement nameField = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class='w-full h-full relative z-1 inline-flex justify-center items-center radius-full shrink-0 shadow-dark-md xs:shadow-none bg-gray-600']//*[name()='svg']//*[name()='path' and contains(@fill-rule,'evenodd')]")));
            nameField.click();
            
            // Step 7: Drag and drop "Full Name" field into form canvas
            WebElement fullNameField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Full Name']")));
            WebElement dropTarget = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div.form-all")));
           
			actions.clickAndHold(fullNameField).moveToElement(dropTarget).release().build().perform();
			
			// Scroll down by 1000 pixels
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("window.scrollBy(0,3000)");
            Thread.sleep(2000);
            
            // Step 8: Drag and drop "Email" field
            WebElement emailField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Email']")));
            actions.clickAndHold(emailField).moveToElement(dropTarget).release().build().perform();
            
            // Step 9: Drag and drop "Phone" field
            WebElement phone = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Phone']")));
            actions.clickAndHold(phone).moveToElement(dropTarget).release().build().perform();
            
            
            
            // Step 10: Drag and drop "address" field
            WebElement Address = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Address']")));
            actions.clickAndHold(Address).moveToElement(dropTarget).release().build().perform();
                          
            // Step 11: Drag and drop "Long Text" field
            WebElement longTextField = wait.until(ExpectedConditions.visibilityOfElementLocated( By.xpath("//span[text()='Long Text']")));
            actions.clickAndHold(longTextField).moveToElement(dropTarget).release().build().perform();
            Thread.sleep(3000);
                      
            // step 11.1 TextInputfield for "Type a question"
            WebElement longtextInput01 = driver.findElement(By.cssSelector("label[id='label_7'] div[placeholder='Type a question']"));
            longtextInput01.clear();
            longtextInput01.sendKeys("Why you want to enroll ?");
            
            // step 11.2 TextInputfield "Subtitle"
            WebElement LTextInput02 = driver.findElement(By.xpath("//*[@id=\"id_7\"]/div[2]/div/span/span/div/div"));
            LTextInput02.clear();
            LTextInput02.sendKeys("Please describe with a brief note here");
            Thread.sleep(2000);
            
         
           
            // Step 12: Drag and drop "Drop down" field
            WebElement dropdownField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[3]/div[2]/div[3]/ul[2]/li[5]/div[1]/div[2]/span[1]")));
            actions.clickAndHold(dropdownField).moveToElement(dropTarget).release().build().perform();
            Thread.sleep(3000);
           
            // Step 12.1 InputField "Type a Question"
            WebElement titleInput1 = driver.findElement(By.xpath("(//div[contains(@placeholder,'Type a question')])[5]"));
            titleInput1.clear();
            titleInput1.sendKeys("Interested Area?");
            Thread.sleep(2000);
                                 
            // Step 14 : Select "settings"
            WebElement settingBTN = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@id='siteNav_id_settings']")));
            settingBTN.click();
            Thread.sleep(2000);
            
            // step 14.1 REPLACE EXISTING TEXT IN A DIV WITH NEW TEXt
            WebElement titleInput2 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id='title']")));
            titleInput2.clear();
            titleInput2.sendKeys(Keys.BACK_SPACE, Keys.BACK_SPACE,Keys.BACK_SPACE,Keys.BACK_SPACE,"Student Registration");
            Thread.sleep(2000);


            // Step 15: Select "publish"
            WebElement publish = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#siteNav_id_publish")));
            publish.click();
            Thread.sleep(2000);
           
           driver.close();
            
            // Assertions: Ensure the fields are visible
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[contains(text(),'Full Name')]")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[contains(text(),'Email')]")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[contains(text(),'Dropdown')]")));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[contains(text(),'Interested Area?')]")));
            
            System.out.println("Drag and drop actions completed successfully!");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                Thread.sleep(5000);
            } catch (InterruptedException ignored) {}
            driver.quit();
        }
    }



}
